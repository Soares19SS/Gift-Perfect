document.getElementById('form-present').onsubmit = function(event) {
    event.preventDefault();

    // Exibe a animação de carregamento e desabilita o botão de envio
    
    document.getElementById('loading-animation').style.display = 'block';
    document.getElementById('submit-btn').disabled = true;

    // Coleta os dados do formulário
    const idade = document.getElementById('idade').value;
    const interest = document.getElementById('interest').value;
    const relacionamento = document.getElementById('relacionamento').value;

    // Simula o tempo de carregamento (10 segundos)
    setTimeout(function() {

        document.getElementById('botao').style.display = 'none';

        // Lógica de recomendação simulada
        const recommendation = "Relógio esportivo";
        const link = "https://www.farfetch.com/br/shopping/women/versace-relogio-medusa-deco-de-37mm-item-21275890.aspx?storeid=13539";
        const imageUrl = "https://cdn-images.farfetch-contents.com/21/27/58/90/21275890_51310424_1000.jpg";

        // Atualiza a recomendação na página
        document.getElementById('recommendation').innerText = recommendation;
        document.getElementById('recommendation-link').href = link;
        document.getElementById('product-image').src = imageUrl;
        
        // Exibe a recomendação e esconde o formulário
        document.getElementById('loading-animation').style.display = 'none';
        document.getElementById('result-container').style.display = 'block';
        document.getElementById('submit-btn').disabled = false;
    }, 1000); // 10 segundos
};
